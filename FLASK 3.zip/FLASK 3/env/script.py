from flask import *
import random 
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/getOTP', methods = ['POST'])
def getOTP():
    number = request.form['number']
    getOTPApi(number)
    return number

@app.route('/validateOTP', methods = ['POST'])

def verifyOTP():
    otp = request.form['otp']
    if 'response' in session:
        s = session['response']
        session.pop('response',None)
        if  s == otp:
            return 'Access granted'
        else:
            return 'Access blocked'

def generateOTP():
    return random.randrange(100000,999999)    

def getOTPApi(number):
    otp = generateOTP
    session['response'] = str(otp)


if __name__ == "__main__":
    app.run(debug=True)